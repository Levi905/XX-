document.write(`<div id="footer">
<ul>
    <li><i class="bi bi-receipt"></i><br><span><a href="">首页</a></span>
    </li>
    <li><i class="bi bi-play-btn"></i><br><span><a href="">视频</a></span>
    </li>
    <li><i class="bi bi-menu-up"></i><br><span><a href="">详情</a></span>
    </li>
    <li><i class="bi bi-person"></i><br><span><a href="">我的</a></span>
    </li>
</ul>
</div>`);