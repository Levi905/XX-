document.write(`<div id="top-top">
<ul>
    <li><img src="../images/cinema_03.png" alt=""></li>
    <li><img src="../images/cinema_05.png" alt=""></li>
    <li><a href="#">登录</a></li>|
    <li><a href="#">注册</a></li>|
    <li> 全国服务热线：888-8888888</li>
</ul>
</div>
<div id="top-logo">
<div id="top-logo-img">
    <img src="../images/cinema_10.png" alt="">
</div>
<p>佛山<br><span>[更换城市]</span></p>
</div>
<div id="top-nav">
<ul>
    <li class="red"><a href="#">首页</a></li>|
    <li class=""><a href="#">影片</a></li>|
    <li class=""><a href="#">影城</a></li>|
    <li class=""><a href="#">购票</a></li>|
    <li class=""><a href="#">影城活动</a></li>|
    <li class=""><a href="#">会员服务</a></li>|
    <li class=""><a href="#">顾客互动</a></li>|
</ul>
<input type="text" placeholder="搜索影片" id="search"><button id="btn-search"></button>
</div>`);