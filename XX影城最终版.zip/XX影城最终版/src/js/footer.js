document.write(`<div id="footer">
<div id="footer-top">
    <ul>
        <li><img src="../images/cinema_67.png" alt=""> 新手上路</li>
        <li>注册登录问题</li>
        <li>用户绑定会员卡问题</li>
        <li>影票相关问题</li>
        <li>票价和支付问题</li>
        <li>取票凭证吗和取票问题</li>
    </ul>
    <ul>
        <li><img src="../images/cinema_69.png" alt="">购票指南</li>
        <li>用户购票流程</li>
        <li>取票观影指南</li>
        <li>会员卡支付相关说明</li>
        <li>网银支付相关说明</li>
    </ul>
    <ul>
        <li><img src="../images/cinema_72.png" alt="">会员权益</li>
        <li>会员订票权益</li>
        <li>会员积分权益</li>
        <li>入会资格</li>
        <li>会员卡折扣说明</li>
        
    </ul>
    <ul>
        <li><img src="../images/cinema_74.png" alt="">联系我们</li>
        <li>手机客户端介绍与下载</li>
        <li>影片信息查询</li>
        <li>手机自助购票</li>
    </ul>
</div>
<div id="footer-bottom">
    <p>
        公司介绍  -  合作咨询  -  友情链接  -  网站地图  -  站长统计  -  网站声明
    </p>
    <p>
        Copyright © 2013  ed by 
    </p>
</div>
</div>`);